(function() {
  var CALLBACK_URL, COOKIE_SECRET, TW_AS, TW_AT, TW_CK, TW_CS, TwitterAPI;

  TwitterAPI = require('node-twitter-api');

  TW_CK = '3958Pmc7nUTFJKkNTCB6hHPAr';

  TW_CS = 'QrOdT5WSNsVbE94w5906Aa3WfhB7aT3slDAHufhm9IP6enpb9k';

  TW_AT = '898525572-6JqFscJlXhf0T9z09H4Op0mB5m1MeaBmNmOWxdnI';

  TW_AS = 'oyy60LfbNgDxNqmlVWKi9vCZcWrlC4M5oZjm5CkT5VOm0';

  CALLBACK_URL = 'http://127.0.0.1:4040/auth/twitter/callback';

  COOKIE_SECRET = 'tw4oiu32ff3wr21toihfsDSfhio324';

  exports.settings = {
    TW_CK: TW_CK,
    TW_CS: TW_CS,
    TW_AT: TW_AT,
    TW_AS: TW_AS,
    CALLBACK_URL: CALLBACK_URL,
    COOKIE_SECRET: COOKIE_SECRET,
    PORT: 4040,
    GRACE_TIME_SERVER: 0,
    GRACE_TIME_CLEAR: 1 * 1000,
    INTERVAL_TIME_CLEAR: 10 * 1000,
    FRINEDS_LIST_COUNT: 100,
    MAX_NUM_GET_TIMELINE_TWEET: 100,
    MAX_NUM_GET_LISTS_LIST: 100,
    MAX_NUM_GET_FAV_TWEET_FROM_LIST: 200,
    MAX_NUM_GET_LIST_STATUSES: 200,
    MAX_NUM_GET_LIST_MEMBERS: 5000,
    twitterAPI: new TwitterAPI({
      consumerKey: TW_CK,
      consumerSecret: TW_CS,
      callback: CALLBACK_URL
    }),
    defaultUserIds: '87658369,123720322,124814283,437523928,2228681658',
    targetList: ['g1un1u', 'kamikannda', 'loliconder', 'nosongang', 'sandworks', 'exit_kureaki', 'yamayo']
  };

}).call(this);
